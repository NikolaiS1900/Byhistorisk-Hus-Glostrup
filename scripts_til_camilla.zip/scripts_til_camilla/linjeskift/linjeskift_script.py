import glob, os


cwd = os.getcwd()

for filename in glob.glob(cwd+'/Måltekst/*.txt'):
	with open(filename, 'r', encoding="utf8") as f:
		read_tekst = f.read()


ny_tekst = open(str(cwd)+'/Resultat/tekst_med_linjeskift.txt', 'w', encoding="utf8")


replace = read_tekst.replace('&&', '\n \n')


ny_tekst.write("" + replace)


ny_tekst.close()

print("""Resultatet er klart.
- Mvh. Nikolai Sandbeck

Besøg min github: https://github.com/NikolaiS1900
Jeg kan kontaktes på: sandbecks_github@protonmail.com""")
