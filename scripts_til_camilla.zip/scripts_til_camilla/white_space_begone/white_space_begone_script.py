import glob, os


cwd = os.getcwd()


for filename in glob.glob(cwd+'/Måltekst/*.txt'):
	with open(filename, 'r', encoding="utf8") as f:
		read_tekst = f.read()


renset_tekst = open(str(cwd)+'/Resultat/gone_is_whitespace_tekst.txt', 'w', encoding="utf8")



splitter = read_tekst.split()


rens = ' '.join(splitter)


renset_tekst.write("" + rens) 

renset_tekst.close()


print("""Resultatet er klart.
- Mvh. Nikolai Sandbeck

Besøg min github: https://github.com/NikolaiS1900
Jeg kan kontaktes på: sandbecks_github@protonmail.com""")
