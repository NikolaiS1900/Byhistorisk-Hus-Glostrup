# importerer glob, os, og re
import glob, os, re

# Finder curent working directory
cwd = os.getcwd()

# Kører en forloop der tjekker mappten Måltekst for filder der ender på .txt.
# Det er vigtigt at der kun ligger én tekstfil i mappen.
# Tekstfilen bliver læst, og det læste bliver gemt i variablen read_target.
for filename in glob.glob(cwd+'/Måltekst/*.txt'):
	with open(filename, 'r', encoding="utf8") as f:
		read_target = f.read()

# Gør det samme som oven for, bare med mappen Tegnliste, og den gemmer reslutat i varaiblen
# read_tegnliste.
for filename in glob.glob(cwd+'/Tegnliste/*.txt'):
	with open(filename, 'r', encoding="utf8") as f:
		read_tegnliste = f.read()

# tager teksten i read_tegnliste, og laver den om til en liste.
# Dette ekstra trin, sikrer at alt bliver rigtigt stillet op.
list_tegnliste = read_tegnliste.split()

# Hvis vi har \ i teksten, så vil tegnliste også have \.
# Når Python skal importere indholdet af en tekstfil der har \\, bliver den nødt til at sige \\
# Derfor gemmer vi \\ i variablen backslash
backslash = '\\'

# Denne loop går ind og tjekker om \\ er i vores måltekst.
# Hvis ja, så går den inder og fjerner det. Siden vi nu har to, bliver
# vi nødt til at sige erstat \\\\ med 0 i målteksten.
# Når det er gjort, bliver variablen read_target lavet om
# og tilskrevet den nye tekst.
# Hvis ikke, så hopper den passerer den bare videre.
for i in read_target:
	if backslash in list_tegnliste:
		read_target = re.sub('\\\\', '', read_target)
	else:
		pass

# Opretter en tom tekstfil i mappen Resultat, og kalder denne tekstfil for "renset_tekst.txt.
# Denne fil holdes åbent i write mode.
renset_tekst = open(str(cwd)+'/Resultat/renset_tekst.txt', 'w')

# Tager teksten i listen list_tegnliste, og bruger ''.join()
# for at fjerne alle , og '' fra listen.
# Den danner nu et regex-mønster med alle tegn vi skal have fjernet
# omklamrer dem med [ ] for at sige det er disse tegn der gælder (0 eller flere).
# Dette gemmes i varialben pattern.
pattern = '[' + ''.join(list_tegnliste) + ']'

# tager regex-mønsteret der er gemt i pattern,
# og erstatter alle forekomster i read_target med ingenting
# Dette gemmes i variablen renset_streng.
renset_streng = re.sub(pattern, '', read_target)

# tager fat i den tomme tekst der er gemt i renset_tekst, og 
# tilføjer indholdet af renset_streng.
renset_tekst.write("" + renset_streng)

# Lukker den nye tekstfil.
renset_tekst.close

# Udskriver en hilsen.
print("""Resultatet er klart.
-Mvh. Nikolai Sandbeck 

Besøg min github: https://github.com/NikolaiS1900""")
